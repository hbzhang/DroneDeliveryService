package com.example.dronedeliveryservice

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import kotlinx.android.synthetic.main.activity_product_name.*

class ProductName : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_product_name)

        next_dimensions.setOnClickListener {
            val intent = Intent(this, ProductDimensions::class.java)
            startActivity(intent)
        }
    }
}