package com.example.dronedeliveryservice

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity

class ProductDimensions : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_product_dimensions)
    }
}